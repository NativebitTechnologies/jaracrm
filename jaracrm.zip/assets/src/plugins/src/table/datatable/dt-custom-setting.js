var DTcustomsetting = {
    languagePagination: {
        "paginate": {
          "previous": "<i class='flaticon-left-arrow-1'></i>",
          "next": "<i class='flaticon-right-arrow-1'></i>"
        },
        "info": "Showing page _PAGE_ of _PAGES_"
    },



};



var DTcustomsetting = {
    languagePagination: {
        "paginate": {
          "previous": "<i class='flaticon-left-arrow-1'></i>",
          "next": "<i class='flaticon-right-arrow-1'></i>"
        },
        "info": "Showing page _PAGE_ of _PAGES_"
    },

    languagePaginate: {
        "previous": "<i class='flaticon-left-arrow-1'></i> Previous",
        "next": "Next <i class='flaticon-right-arrow-1'></i>"
    },

    languageInfo: {
    	info: "Showing page _PAGE_ of _PAGES_"
    }
    
};
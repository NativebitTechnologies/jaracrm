	
	<!-- END MAIN CONTAINER -->
		<?php
		    $this->load->view('includes/footerfiles');
		    $this->load->view('includes/modal');
		?>
	</body>
</html>